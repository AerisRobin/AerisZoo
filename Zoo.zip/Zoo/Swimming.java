
/**
 * Write a description of interface Swimming here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Swimming
{
    public String swim();
}
