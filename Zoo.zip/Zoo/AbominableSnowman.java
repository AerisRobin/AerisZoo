
/**
 * Abstract class AbominableSnowman - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class AbominableSnowman extends Animal 
implements Walking
{
    public AbominableSnowman()
    {
        /*
         *  Call my other constructor that takes two Strings
         *  Again, this is called constructotr chaining
         */
        this("Snowy the Abominable snowman", "Lives in freezing snowy areas");
    }
    
    public AbominableSnowman(String name, String description)
    {
        /*
         * super means call something in my parent class (Animal), in this
         * case I am calling the constructor in my aprent that takes
         * two paramenters and sending in the name and description that 
         * were passed into this constructor
         */
        
        
        super(name, description);
    }
    
    @Override
    public String eat()
    {
        return "Eats people, snow, and ice";
    }
    
    @Override
    public String makeNoise()
    {
        return "BURRRRERRRRRR";
    }
    
     @Override
    public String walk()
    {
        return "Step step steppy";
    }
    
     @Override
    public String talk()
    {
        return " Ahhhh! I just said bet your buns to a nun!";
    }
}
