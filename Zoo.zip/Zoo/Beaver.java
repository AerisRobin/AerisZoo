
/**
 * Abstract class Beaver - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Beaver extends Animal
        implements Swimming, Walking

{
    /**
     * Construction for objects of class Llama
     */
    public Beaver()
    {
        this("Beaves the Beaver 🦡  " , "Left to me");
        
    }
    
    /**
     * Beaver Constructor
     *
     * @param name A parameter
     * @param description A parameter
     */
    public Beaver(String name, String description) {
        super(name, description);
    }
    
    @Override 
    public String eat()
    {
        return "Actually enjoys wood";
    }
    
    @Override
    public String makeNoise()
    {
        return "Chompp";
    }
    
     @Override
    
    public String swim()
    {
      return "Flap flap flap...";
    }
    
    @Override
    
    public String walk()
    {
      return "Tail slaps the ground as Beave walks around";
    }
     @Override
    public String talk()
    {
        return "We can't just say we're going to be friends. We gotta have an agreement or something. ";
    }
}

