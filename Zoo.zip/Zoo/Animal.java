
/**
 * Abstract class Animal - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Animal
{
    protected String name;
    protected String description;
    //This variable is static; it belongs to the Animal class
    public static int numAnimals = 0;

    /* 
     * Constructor for objects of class Animal
     */
    public Animal() {
        //Call the other constructor that takes on String parameter'
        //passing in none for the name
        // This is call constructor chaining when one constructor
        // calls another
        this("none");
    }

    public Animal(String name) {
        //Call the other constructor that takes two String parameters;
        // passing in the value referenced by the name variable and
        // none for the description
        this(name, "none");
    }

    public Animal( String name, String description) {
        //Set the name and description for the animal
        this.name = name;
        this.description = description;
        // Incrememnt the numAnimals in indicating that another animal has
        //been created
        numAnimals++;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public String getDescription(){
        return this.description;
    }

    @Override

    public String toString(){
        return this.name + " : " + this.description;
    }
    /*
     * Abstract methods do not have a body. The define that any 
     * class that inherits (extends) from this class must override
     * this method i.e. if Rhino extends Animal, it must have an eat()
     * method
     */
    public abstract String eat();
    
    public abstract String makeNoise();
    
    public abstract String talk();
}
