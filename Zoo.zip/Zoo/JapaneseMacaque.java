
/**
 * Write a description of class MapaneseMacaque here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class JapaneseMacaque extends Animal implements Walking
{ 
    public JapaneseMacaque()
    {
        this("Ichika", "Just Waking Up");
    }
    
    public JapaneseMacaque(String name, String Decription)
    {
        super(name, Decription);
    }
    
    @Override
    
    public String makeNoise()
    {
       return "Oh Oh";
    }
    
    @Override
    
    public String eat()
    {
       return "Yum";
    }
    
    @Override
    
    public String walk()
    {
       return "*Thud**Thud*";
    }
     @Override
    public String talk()
    {
        return " Hot springs are the best!";
    }
}
