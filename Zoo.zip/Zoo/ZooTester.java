import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.Random; 
import java.util.Scanner;
/**
 * Write a description of class ZooTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ZooTester
{
    public static void main(String[] args) throws InterruptedException
    {
        List<Animal> animals = new ArrayList<Animal>();

        System.out.println("  _             _                _  _                                                                       _                                    _         _                                     _  _  _  _  _                                         _          ");
        System.out.println(" (_)           (_)              (_)(_)                                                                     (_)                                  (_)       (_)                                   (_)(_)(_)(_)(_)                                       (_)           ");
        System.out.println(" (_)           (_)  _  _  _  _     (_)     _  _  _    _  _  _      _  _   _  _    _  _  _  _             _ (_) _  _      _  _  _              _ (_) _  _  (_) _  _  _     _  _  _  _                      _(_)    _  _  _        _  _  _              (_)           ");
        System.out.println(" (_)     _     (_) (_)(_)(_)(_)_   (_)   _(_)(_)(_)_ (_)(_)(_) _  (_)(_)_(_)(_)  (_)(_)(_)(_)_          (_)(_)(_)(_)  _ (_)(_)(_) _          (_)(_)(_)(_) (_)(_)(_)(_)_  (_)(_)(_)(_)_                  _(_)   _ (_)(_)(_) _  _ (_)(_)(_) _           (_)           ");
        System.out.println(" (_)   _(_)_   (_)(_) _  _  _ (_)  (_)  (_)       (_)         (_)(_)   (_)   (_)(_) _  _  _ (_)            (_)       (_)         (_)            (_)       (_)        (_)(_) _  _  _ (_)               _(_)    (_)         (_)(_)         (_)          (_)           ");
        System.out.println(" (_)  (_) (_)  (_)(_)(_)(_)(_)(_)  (_)  (_)       (_)         (_)(_)   (_)   (_)(_)(_)(_)(_)(_)            (_)     _ (_)         (_)            (_)     _ (_)        (_)(_)(_)(_)(_)(_)             _(_)      (_)         (_)(_)         (_)                        ");
        System.out.println(" (_)_(_)   (_)_(_)(_)_  _  _  _  _ (_) _(_)_  _  _(_) _  _  _ (_)(_)   (_)   (_)(_)_  _  _  _              (_)_  _(_)(_) _  _  _ (_)            (_)_  _(_)(_)        (_)(_)_  _  _  _            _ (_) _  _  _(_) _  _  _ (_)(_) _  _  _ (_)           _            ");
        System.out.println("   (_)       (_)    (_)(_)(_)(_)(_)(_)(_) (_)(_)(_)  (_)(_)(_)   (_)   (_)   (_)  (_)(_)(_)(_)               (_)(_)     (_)(_)(_)                 (_)(_)  (_)        (_)  (_)(_)(_)(_)          (_)(_)(_)(_)(_)  (_)(_)(_)      (_)(_)(_)             (_)           ");

        System.out.print("Building the cages");
        delayDots();
        System.out.print("Populating the animals");
        populateAnimals(animals);
        delayDots();
        System.out.print("Hiring zookeepers");
        delayDots();

        Scanner in = new Scanner(System.in);
        System.out.println("\nYou are standing in a breath-taking zoo. What would you like to do?");
        System.out.println("Type help to find out what you can do.\n");
        String text = in.nextLine();
        String msg = "";
        while(!text.equals("leave"))
        {
            switch(text)
            {
                case "help" :
                msg = "So far we can visit cages, listen , lunchtime, \n" +
                "look up, look around, look down, leave, talk to animals\n" +
                " and ask for help.";
                break; 
                case "visit cages" :
                msg = visitCages(animals);
                break;
                case "lunchtime" : 
                msg = lunchTime(animals);
                break;
                case "look up" : 
                msg = lookUp(animals);
                break;
                case "look around" :
                msg = lookAround(animals);
                break;
                case "look down" :
                msg = lookDown(animals);
                break;
                case "talk to animals" :
                msg = talkToAnimals(animals);
                break;
                

                default : msg = "You have troubles with deciding."; 
            }
            System.out.println("\n" + msg);
            delayDots(3);
            System.out.println("");
            text = in.nextLine();
        }

    }

    public static String visitCages(List<Animal> animals)
    {
        String msg = "";
        for (Animal a : animals)
        {
            msg += a.getName()+ ": \n      " + a.getDescription() + "\n";
        }
        return msg;
    }

    public static String lunchTime(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n      "
            + a.eat() + "\n";
        }
        return msg;

    }

    public static String lookUp(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals) 
        {
            if(a instanceof Flying)
            {
                Flying f = (Flying) a;
                msg += a.getClass().getName() + ": " + a.getName() + " : \n        "
                + f.fly() + "\n";
            }

        } 
        return msg;
    }

    public static String lookDown(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals) 
        {
            if(a instanceof Swimming)
            {
                Swimming s = (Swimming) a;
                msg += a.getClass().getName() + ": " + a.getName() + " : \n        "
                + s.swim() + "\n";
            }

        } 
        return msg;
    }

    public static String lookAround(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals) 
        {
            if(a instanceof Walking)
            {
                Walking w = (Walking) a;
                msg += a.getClass().getName() + ": " + a.getName() + " : \n        "
                + w.walk() + "\n" ;
            }

        }
        return msg;
    }

    public static String talkToAnimals(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n      "
            + a.eat() + "\n";
        }
        return msg;

    }
        
    public static void populateAnimals(List<Animal> animals)
    {
        Llama l  = new Llama();
        animals.add(l);

        Duck d = new Duck();
        animals.add(d);

        Beaver b = new Beaver();
        animals.add(b);

        SunBear sb  = new SunBear();
        animals.add(sb);

        Moblin m  = new Moblin();
        animals.add(m);

        Droid dr  = new Droid();
        animals.add(d);

        JapaneseGiantSalamander j  = new JapaneseGiantSalamander();
        animals.add(j);

        Trex t  = new Trex();
        animals.add(t);

        Goomba g  = new Goomba();
        animals.add(g);

        Lochnessmonster lo  = new Lochnessmonster();
        animals.add(lo);

        Anaconda a  = new Anaconda();
        animals.add(a);

        RedCrowCrane r  = new RedCrowCrane();
        animals.add(r);

        nakedMoleRats  n = new nakedMoleRats();
        animals.add(n);

        MourningDove md  = new MourningDove();
        animals.add(md);

        Thwomp th = new Thwomp();
        animals.add(th);

        Walter w  = new Walter();
        animals.add(w);

        RedPanda rp  = new RedPanda();
        animals.add(rp);

        Bigfoot bf  = new Bigfoot();
        animals.add(bf);

        Lizalfo li  = new Lizalfo();
        animals.add(li);

        Bokoblin bo  = new Bokoblin();
        animals.add(bo);

        GoldFish gf = new GoldFish();
        animals.add(gf);

        AbominableSnowman as  = new AbominableSnowman();
        animals.add(as);

        LR57CombatDroid lr = new LR57CombatDroid();
        animals.add(lr);

        HomunculusFleshPuppet mf = new HomunculusFleshPuppet();
        animals.add(mf);

        Shark s  = new Shark();
        animals.add(s);                                                                                                                                                                           

        Bunny bu  = new Bunny();
        animals.add(bo);

        Phish ph  = new Phish();
        animals.add(ph);

        Platypus p  = new Platypus();
        animals.add(p);

        Bella be  = new Bella();
        animals.add(be); 

        Rhino ri  = new Rhino();
        animals.add(ri); 

        IronTarkus ir  = new IronTarkus();
        animals.add(ir);

        Vince v = new Vince();
        animals.add(v);

        Megalodon me = new Megalodon();
        animals.add(me);

        JapaneseMacaque jm = new JapaneseMacaque();
        animals.add(jm);

        FleshMonster fm = new FleshMonster();
        animals.add(fm);

        Chimpanzee c = new Chimpanzee();
        animals.add(c);

        Sheep sh = new Sheep();
        animals.add(sh);

        


    }

    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for (int i=0; i<dotAmount; i++) {
            TimeUnit.SECONDS.sleep(1);
            System.out.print(" 🕰 ");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }

}

