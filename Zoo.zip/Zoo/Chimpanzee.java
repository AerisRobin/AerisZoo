
/**
 * Abstract class Chimpanzee - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Chimpanzee extends Animal
implements Walking
{
    /**
     * Construction for objects of class Llama
     */
    public Chimpanzee()
    {
        this("Jim the loving Chimp 🐒" , "Is the father and knows best");

    }

    /**
     * Llama Constructor
     *
     * @param name A parameter
     * @param description A parameter
     */
    public Chimpanzee(String name, String description) {
        super(name, description);
    }

    @Override 
    public String eat()
    {
        return "Munches on some juicy fruits after a long day at the office";
    }

    @Override
    public String makeNoise()
    {
        return "Screams at children";
    }

    @Override

    public String walk()
    {
        return " Feet slap on the ground";
    }

    @Override
    public String talk()
    {
        return "Well, you know what they say - Father... ";
    }
}

