public interface Spinning
{
    public String spin();
}