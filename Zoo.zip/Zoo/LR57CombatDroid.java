
/**
 * Write a description of class LR57CombatDroid here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LR57CombatDroid extends Animal
implements Walking
{
public LR57CombatDroid() {
 this("LR-57 combat serperaist droid" , "lives on the pleasure of mass galactic genocide");
  }  
public LR57CombatDroid(String name, String description) {
    super(name, description);
}
@Override

public String eat() {
   return("eats any lifeforms");
}
@Override
public String makeNoise() {
    return("can clanking noisees");
}
@Override
public String walk() {
    return "Crawl and wriggle";
}
 @Override
    public String talk()
    {
        return " I kill things and enjoy it.";
    }
}
