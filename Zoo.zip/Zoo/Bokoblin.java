
/**
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public class Bokoblin extends Animal implements Walking
{

    /**
     * Construction for objects of class bokoblin
     */
    public Bokoblin()
    {
        this("Bepis the bokoblin" , "''I hit with club''");
    }
    public Bokoblin(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "meat";
    }
    @Override
    public String makeNoise()
    {
        return "REEEEE";
    }
    @Override
    public String walk()
    {
        return "skitter, wobble";
        
    }
     @Override
    public String talk()
    {
        return " I will whack!";
    }
    
}