
/**
 * Abstract class Sheep - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Sheep extends Animal
    implements Walking
{
    
    
    /**
     * Construction for objects of class Llama
     */
    public Sheep()
    {
        
        this("Shirley the Sheep 🐑?" , "Laverne's best friend");
        
    }
    
    /**
     * Llama Constructor
     *
     * @param name A parameter
     * @param description A parameter
     */
    public Sheep(String name, String description) {
        super(name, description);
    }
    
    @Override 
    public String eat()
    {
        return "Gracefully monches on grass";
    }
    
    @Override
    public String makeNoise()
    {
        return "Baaaa";
    }
    
     @Override
    
    public String walk()
    {
      return "Hooves clack on the pavement";
    }
    
    @Override
    public String talk()
    {
        return " I'm telling you, flying is safer than driving! Nobody has ever crashed into a cloud!";
    }
}


