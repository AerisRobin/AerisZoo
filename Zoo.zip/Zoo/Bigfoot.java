
/**
 * Abstract class Bigfoot - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Bigfoot extends Animal 
implements Walking
{
    public Bigfoot()
    {
        /*
         *  Call my other constructor that takes two Strings
         *  Again, this is called constructotr chaining
         */
        this("Alihondra the Bigfoot", "Lives in dense woods and kills trasspares on his territory");
    }
    
    public Bigfoot(String name, String description)
    {
        /*
         * super means call something in my parent class (Animal), in this
         * case I am calling the constructor in my aprent that takes
         * two paramenters and sending in the name and description that 
         * were passed into this constructor
         */
        
        
        super(name, description);
    }
    
    @Override
    public String eat()
    {
        return "Eats people";
    }
    
    @Override
    public String makeNoise()
    {
        return "AHHHwhabdbad RAAAAA aasdsafsrvs AHAHHAH afashdf";
    }
    
    @Override
    public String walk()
    {
        return "Boom Boom Boom";
    }
     @Override
    public String talk()
    {
        return " Please just let me be! I have a wife and kids!!!";
    }
}
